#pragma once
#include "Mario.h"


void Mario::moveMario() {
	setBoolMoves();
	if (!mario.IsOnFloor() && !jumping && !onLadderUp && !onLadderDown) {
		mario.moveOneDown();
		fallCounter++;
		if (fallCounter == 5) {
			die(); // TO-DO
		}
	}
	else if (jumping) {
		if (jumpingCounter <= 2) {
			mario.setDirection(mario.directions[2]);
		}

		jumping = mario.moveOneByDirection();
		jumpingCounter--;

		if (jumpingCounter == 0) {
			jumping = false;
			jumpingCounter = 4;
			mario.setDirections(mario.prevDir);
		}
	}
	else if (onLadderUp && !onLadderDown) {
		if (!IsBelowFloor()) mario.moveOneUp();
		else {
			moveAboveFloor();
			mario.stay();
			onLadderUp = false;
		}
	}
	else if (onLadderDown && !onLadderUp) {
		if (!mario.IsOnFloor()) {
			mario.moveOneDown();
			mario.stay();
			onLadderDown = false;
		}
		else moveBelowFloor();
	}
	else {
		mario.move();
	}
}

void Mario::setBoolMoves() {
	if (mario.IsNextDirectionUp()) {
		if (mario.pBoard->getChar(mario.x, mario.y) == 'H') {
			onLadderUp = true;
		}
		else {
			jumping = true;
		}
	}
	if (mario.IsNextDirectionDown()) {
		if (mario.pBoard->getChar(mario.x, mario.y + 2) == 'H') {
			onLadderDown = true;
		}
	}
}


void Mario::climb() {
	mario.moveOneUp();
	mario.pBoard->setChar(mario.x, mario.y + 1, 'H');
	while (!IsBelowFloor()) {
		mario.moveOneUp();
		mario.pBoard->setChar(mario.x, mario.y + 1, 'H');
	}
	moveAboveFloor();
}

void Mario::climbDownLadder() {
	moveBelowFloor();
	while (!mario.IsOnFloor()) {
		mario.moveOneDown();
		mario.pBoard->setChar(mario.x, mario.y - 1, 'H');
	}
}

void Mario::moveAboveFloor() {
	int newY = mario.y - 2;
	mario.pBoard->drawOnBoard(mario.x, mario.y);
	mario.y = newY;
	mario.stay();
}


bool Mario::IsBelowFloor() {
	char v = mario.pBoard->getChar(mario.x, mario.y - 1);
	if (v == '=' || v == '>' || v == '<') {
		return true;
	}
	return false;
}

void Mario::moveBelowFloor() {
	int newY = mario.y + 2;
	mario.pBoard->drawOnBoard(mario.x, mario.y);
	mario.y = newY;
	mario.draw(mario.ch);
	 
	mario.stay();
}

void Mario::marioFall() {
	int countFloors = mario.fall();
	if (countFloors >= 5) {
		die();
	}
}

void Mario::die() {

}

void Mario::reachedPauline() {
	return;
}

void Mario::jump() {
	/*mario.moveOneByDirection();
	mario.moveOneByDirection();
	while (!mario.IsOnFloor()) {
		mario.jumpOneDown();
	}
	mario.dir = mario.prevDir;*/

	
}
