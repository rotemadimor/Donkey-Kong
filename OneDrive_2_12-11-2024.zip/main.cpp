#include <iostream>
#include <windows.h>
#include <conio.h>

#include "Board.h"
#include "utils.h"
#include "Mario.h"
#include "Game.h"


int main() {

	Game().run();
	
}
