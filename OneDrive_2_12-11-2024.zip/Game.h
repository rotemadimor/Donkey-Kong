#pragma once

#include <iostream>
#include "Board.h"
#include "utils.h"
#include "Point.h"
#include "Barrel.h"


class Game {
	static constexpr int sizeBarrels = 10;
	Board board;
	Mario player;
	//Barrel barrels[sizeBarrels];
	Barrel noaHaHavit;
	//noaHaHavit = Point(1, 14, 'O');
	int lives = 3;
	public:
		void run();

};

