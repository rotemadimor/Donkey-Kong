#include "Point.h"

void Point::keyPressed(char key) {
	for (size_t i = 0; i < numKeys; i++) {
		if (std::tolower(key) == keys[i]) {
			prevDir = dir;
			dir = directions[i];
			return;
		}
	}
}

void Point::move() {
	int newX = x + dir.x;
	int newY = y + dir.y;
	char currCharOnBoard = pBoard->getChar(x, y);
	char nextCharOnBoard = pBoard->getChar(newX, newY);
	// + Better use a constant for the wall character
	if (IsNewLocationValid(newX, newY, nextCharOnBoard)) {
	 {
			pBoard->drawOnBoard(x, y);
			x = newX;
			y = newY;
		}
	}
}

bool Point::IsOnFloor() {
	char v = this->pBoard->getChar(x, y + 1);
	if (v == '=' || v == '>' || v == '<') {
		return true;
	}
	return false;
}

bool Point::moveOneByDirection() {
	int newY = y + prevDir.y + dir.y;
	int newX = x + prevDir.x + dir.x;
	char nextCharOnBoard = pBoard->getChar(newX, newY);
	if (IsNewLocationValid(newX, newY, nextCharOnBoard)) {
		pBoard->drawOnBoard(x, y);
		y = newY;
		x = newX;
		return true;
	}
	return false;
}
void Point::jumpOneDown() {
	pBoard->drawOnBoard(x, y);
	int newY = y + 1;
	int newX = x + dir.x + prevDir.x;
	if (IsNewLocationValid(newX, newY, pBoard->getChar(newX, newY))) {
		x = newX;
		y = newY;
		draw(ch);
	}
	else fall();
	
}

void Point::jumpOneUp() {
	pBoard->drawOnBoard(x, y);
	y = y - 1;
	x = x + dir.x + prevDir.x;
	draw(ch);
}

void Point::moveOneDown() {
	pBoard->drawOnBoard(x, y);
	y = y + 1;
}

void Point::moveOneUp() {
	pBoard->drawOnBoard(x, y);
	y = y - 1;
	 
}
int Point::fall() {
	int countFloors = 0;
	while (!IsOnFloor()) {
		moveOneDown();
		countFloors++;
	}
	return countFloors;
}

bool Point::IsNewLocationValid(int newX, int newY, char nextCharOnBoard) {
	if (nextCharOnBoard == '=' || nextCharOnBoard == '<' || nextCharOnBoard == '>'){
		return false;
	}
	return (newX < 80 && newY < 24) && (newX >= 0 && newY > 0);
}
