#pragma once

#include <iostream>
#include "Board.h"
#include "utils.h"
#include "Point.h"

class Mario {
	bool jumping = false, onLadderUp = false, onLadderDown = false;
	int fallCounter = 0;
	int jumpingCounter = 4;
public:
	Point mario;
	void climb();
	void climbDownLadder();
	void moveMario();
	void jump();

	void setBoolMoves();
	void marioFall();
	void moveAboveFloor();
	bool IsBelowFloor();
	void moveBelowFloor();
	//void hitBarrels();
	void reachedPauline();
	void die();

};