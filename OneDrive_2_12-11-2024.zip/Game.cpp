#pragma once

#include <iostream>
#include <windows.h>
#include <conio.h>
#include "Board.h"
#include "utils.h"
#include "Point.h"
#include "Mario.h"
#include "Game.h"

static constexpr int ESC = 27;

void Game::run() {
	

	ShowConsoleCursor(false);
	board.reset();
	board.print();
	player.mario.setBoard(board);
	player.mario.setChar('@');
	noaHaHavit.born();
	noaHaHavit.barrel.setBoard(board);

	while (lives > 0) {
		player.mario.draw();
		noaHaHavit.barrel.draw();
		//Sleep(200);
		
		/*HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
		FlushConsoleInputBuffer(hInput);*/
		if (_kbhit()) {

			char key = _getch();

			if (key == ESC) break;
			player.mario.keyPressed(key);

		}
		Sleep(100);
		player.mario.erase();
		noaHaHavit.barrel.erase();
		player.moveMario();
		

		noaHaHavit.moveBarrel();
	}
	//print

}

